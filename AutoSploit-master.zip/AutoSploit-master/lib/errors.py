class AutoSploitAPIConnectionError(Exception): pass


class NmapNotFoundException(Exception): pass


class NmapScannerError(Exception): pass